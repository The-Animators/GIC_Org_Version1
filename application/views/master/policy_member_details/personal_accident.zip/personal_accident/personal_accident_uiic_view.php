<style>
    table {
        border-collapse: collapse;
        border-spacing: 0;
        width: 100%;
        border: 1px solid #ddd;
    }

    th,
    td {
        text-align: left;
        padding: 8px;
    }

    /* tr:nth-child(even) {
        background-color: #f2f2f2
    } */
</style>
<div class="row">
    <div class="col-md-12" style="overflow-x:auto;">
        <table class="table mb-0 table-bordered" id="first_table">
            <thead>
                <tr>
                    <th><button class="btn btn-primary btn-sm Add_Personal_accident" id="Add_Personal_accident" onclick="AddPersonal_accident(0)">Add</button></th>
                    <th>Name Of Insured</th>
                    <th>DOB</th>
                    <th>Age</th>
                    <th>Sum Insured</th>
                    <th>Premium</th>
                </tr>
            </thead>
            <tbody id="first_table_tbody">
                <tr>
                    <td width="2%"><button class="btn btn-primary btn-sm dripicons-cross" id="remove_personal_accident_0" onClick=removePersonal_accident(0) disabled></td>
                    <td width="12%"><select style="width:280px;" id="name_insured_member_name_0" name="name_insured_member_name[]" class="form-control name_insured_member_name" onchange="get_dob(0)">
                            <option value="null">Select Member Names</option>
                        </select></td>
                    <td width="8%"><input style="width:100px;" type="text" id="name_insured_dob_0" name="name_insured_dob[]" value="" class="form-control name_insured_dob"></td>

                    <td width="5%"><input style="width:55px;" type="text" id="name_insured_age_0" name="name_insured_age[]" value="" class="form-control name_insured_age"></td>

                    <td width="20%"><div class="row"><div class="col-md-3 col-form-label text-right">Table 1:</div><div class="col-md-9"><select style="width:180px;" id="name_insured_sum_insured_0_1" name="name_insured_sum_insured[]" class="form-control name_insured_sum_insured_1" onchange="get_premium(0)"><option value="null">Select Sum Insured</option></select></div><div class="col-md-3 col-form-label text-right">Table 2:</div><div class="col-md-9"><select style="width:180px;" id="name_insured_sum_insured_0_2" name="name_insured_sum_insured[]" class="form-control name_insured_sum_insured_2 mt-1" onchange="get_premium(0)"><option value="null">Select Sum Insured</option></select></div><div class="col-md-3 col-form-label text-right">Table 3:</div><div class="col-md-9"><select style="width:180px;" id="name_insured_sum_insured_0_3" name="name_insured_sum_insured[]" class="form-control name_insured_sum_insured_3 mt-1" onchange="get_premium(0)"><option value="null">Select Sum Insured</option></select></div><div class="col-md-3 col-form-label text-right">Table 4:</div><div class="col-md-9"><select style="width:180px;" id="name_insured_sum_insured_0_4" name="name_insured_sum_insured[]" class="form-control name_insured_sum_insured_4 mt-1" onchange="get_premium(0)"><option value="null">Select Sum Insured</option></select></div><div class="col-md-3 col-form-label text-right">Sum Insured:</div><div class="col-md-9"><input style="width:180px;" type="text" id="sum_insured_0" name="sum_insured[]" class="form-control sum_insured mt-1" ></div></td>
                   
                    <td width="20%"><div class="row"><div class="col-md-3 col-form-label text-right">Table 1:</div><div class="col-md-9"><input style="width:180px;" type="text"  id="name_insured_premium_0_1" name="name_insured_premium[]" class="form-control name_insured_premium_1" ></div><div class="col-md-3 col-form-label text-right">Table 2:</div><div class="col-md-9"><input style="width:180px;" type="text"  id="name_insured_premium_0_2" name="name_insured_premium[]" class="form-control name_insured_premium_2 mt-1" ></div><div class="col-md-3 col-form-label text-right">Table 3:</div><div class="col-md-9"><input style="width:180px;" type="text"  id="name_insured_premium_0_3" name="name_insured_premium[]" class="form-control name_insured_premium_3 mt-1" ></div><div class="col-md-3 col-form-label text-right">Table 4:</div><div class="col-md-9"><input style="width:180px;" type="text"  id="name_insured_premium_0_4" name="name_insured_premium[]" class="form-control name_insured_premium_4 mt-1" ></div><div class="col-md-3 col-form-label text-right">Premium:</div><div class="col-md-9"><input style="width:180px;" type="text" id="premium_0" name="premium[]" class="form-control premium mt-1" ></div></div></td>
                </tr>

            </tbody>
        </table>
    </div>
    <div class="col-md-12">
        <table class="table mb-0 table-bordered mt-2 col-md-12">
            <tr id="declaration_sale_fig_tr">
                <td colspn="2"><strong>Total Premium: </strong></td>
                <td colspn=""><strong></strong></td>
                <td colspn=""><strong></strong></td>
                <td><strong id="paccident_total_premium_td"><input type="text" id="paccident_total_premium" name="paccident_total_premium" class="form-control" disabled></strong></td>
            </tr>
            <tr id="annual_turn_over_tr">
                <td colspn=""><strong> Less Discount In Percent: </strong></td>

                <td colspn=""><strong><input type="text" id="paccident_less_discount_rate" name="paccident_less_discount_rate" class="form-control" onkeyup="medi_family_disc_tot_Cal()"></strong></td>
                <td colspn=""><strong></strong></td>
                <td><strong id="paccident_tot_less_discount_td"><input type="text" id="paccident_tot_less_discount" name="paccident_tot_less_discount" class="form-control" disabled></td>
            </tr>
            <tr id="tot_sum_insured_tr">
                <td colspn="3"><strong> Gross Premium: </strong></td>
                <td colspn=""><strong></strong></td>
                <td colspn=""><strong></strong></td>
                <td><strong id="paccident_gross_premium_td"><input type="text" id="paccident_gross_premium" name="paccident_gross_premium" class="form-control" disabled></td>
            </tr>
            <tr>
                <td colspn=""><strong> CGST:</strong></td>
                <td><strong id="paccident_cgst_rate_td"><input type="text" id="cgst_fire_per" name="paccident_cgst_rate" class="form-control" onkeyup="gst_apply()"></td>
                <td><strong id=""></strong></td>
                <td><strong id="paccident_cgst_tot_td"><input type="text" id="paccident_cgst_tot" name="paccident_cgst_tot" class="form-control" disabled></td>
            </tr>
            <tr>
                <td><strong> SGST</strong></td>
                <td><strong id="paccident_sgst_rate_td"><input type="text" id="sgst_fire_per" name="paccident_sgst_rate" class="form-control" onkeyup="gst_apply()"></td>
                <td><strong id=""></strong></td>
                <td><strong id="paccident_sgst_tot_td"><input type="text" id="paccident_sgst_tot" name="paccident_sgst_tot" class="form-control" disabled></td>
            </tr>
            <tr>
                <td colspn="3"><strong class="text-purple">Final Premium</strong></td>
                <td colspn="2"><strong></strong></td>
                <td colspn="2"><strong></strong></td>
                <td><strong id="paccident_final_premium_td"><input type="text" id="paccident_final_premium" name="paccident_final_premium" class="form-control" disabled><input type="hidden" id="paccident_policy_id" name="paccident_policy_id" class="form-control" ></td>
            </tr>
        </table>
    </div>
</div>

<script>
    var sum_insured_dropdown_val = "";
    var add_pa_counter = 0;
    var main_Personal_accident = [];
    function removePersonal_accident(add_pa_counter) {
        $("#remove_personal_accident_" + add_pa_counter).closest("tr").remove();
        main_Personal_accident.splice(main_Personal_accident.indexOf(add_gpa_counter), 1);
        // var indexValue = main_Personal_accident.indexOf(add_pa_counter);
        //     main_Personal_accident.splice(indexValue, 1);
            // alert(main_Personal_accident);
        if (main_Personal_accident.length == 0) {
            add_pa_counter=0;
            main_Personal_accident = [];
            $("#Add_Personal_accident").attr("onClick", "AddPersonal_accident(" + add_pa_counter + ")");
        }
        medi_ncd_amount_Cal();
        medi_total_amount_Cal();
    }

    function AddPersonal_accident(add_pa_counter) {
        add_pa_counter = add_pa_counter + 1;
        // alert(add_pa_counter);

        main_Personal_accident.push(add_pa_counter);
        $("#Add_Personal_accident").attr("onClick", "AddPersonal_accident(" + add_pa_counter + ")");
        var tr_table = '<tr><td width="2%"><button class="btn btn-primary btn-sm dripicons-cross" id="remove_personal_accident_'+add_pa_counter+'" onClick=removePersonal_accident('+add_pa_counter+') disabled></td><td width="12%"><select style="width:280px;" id="name_insured_member_name_'+add_pa_counter+'" name="name_insured_member_name[]" class="form-control name_insured_member_name" onchange="get_dob('+add_pa_counter+')"><option value="null">Select Member Names</option></select></td><td width="8%"><input style="width:100px;" type="text" id="name_insured_dob_'+add_pa_counter+'" name="name_insured_dob[]" value="" class="form-control name_insured_dob"></td> <td width="5%"><input style="width:55px;" type="text" id="name_insured_age_'+add_pa_counter+'" name="name_insured_age[]" value="" class="form-control name_insured_age"></td>  <td width="20%"><div class="row"><div class="col-md-3 col-form-label text-right">Table 1:</div><div class="col-md-9"><select style="width:180px;" id="name_insured_sum_insured_'+add_pa_counter+'_1" name="name_insured_sum_insured[]" class="form-control name_insured_sum_insured_1" onchange="get_premium('+add_pa_counter+')"><option value="null">Select Sum Insured</option>'+sum_insured_dropdown_val+'</select></div><div class="col-md-3 col-form-label text-right">Table 2:</div><div class="col-md-9"><select style="width:180px;" id="name_insured_sum_insured_'+add_pa_counter+'_2" name="name_insured_sum_insured[]" class="form-control name_insured_sum_insured_2 mt-1" onchange="get_premium('+add_pa_counter+')"><option value="null">Select Sum Insured</option>'+sum_insured_dropdown_val+'</select></div><div class="col-md-3 col-form-label text-right">Table 3:</div><div class="col-md-9"><select style="width:180px;" id="name_insured_sum_insured_'+add_pa_counter+'_3" name="name_insured_sum_insured[]" class="form-control name_insured_sum_insured_3 mt-1" onchange="get_premium('+add_pa_counter+')"><option value="null">Select Sum Insured</option>'+sum_insured_dropdown_val+'</select></div><div class="col-md-3 col-form-label text-right">Table 4:</div><div class="col-md-9"><select style="width:180px;" id="name_insured_sum_insured_'+add_pa_counter+'_4" name="name_insured_sum_insured[]" class="form-control name_insured_sum_insured_4 mt-1" onchange="get_premium('+add_pa_counter+')"><option value="null">Select Sum Insured</option>'+sum_insured_dropdown_val+'</select></div><div class="col-md-3 col-form-label text-right">Sum Insured:</div><div class="col-md-9"><input style="width:180px;" type="text" id="sum_insured_'+add_pa_counter+'" name="sum_insured[]" class="form-control sum_insured mt-1" ></div></td>   <td width="20%"><div class="row"><div class="col-md-3 col-form-label text-right">Table 1:</div><div class="col-md-9"><input style="width:180px;" type="text"  id="name_insured_premium_'+add_pa_counter+'_1" name="name_insured_premium[]" class="form-control name_insured_premium_1" ></div><div class="col-md-3 col-form-label text-right">Table 2:</div><div class="col-md-9"><input style="width:180px;" type="text"  id="name_insured_premium_'+add_pa_counter+'_2" name="name_insured_premium[]" class="form-control name_insured_premium_2 mt-1" ></div><div class="col-md-3 col-form-label text-right">Table 3:</div><div class="col-md-9"><input style="width:180px;" type="text"  id="name_insured_premium_'+add_pa_counter+'_3" name="name_insured_premium[]" class="form-control name_insured_premium_3 mt-1" ></div><div class="col-md-3 col-form-label text-right">Table 4:</div><div class="col-md-9"><input style="width:180px;" type="text"  id="name_insured_premium_'+add_pa_counter+'_4" name="name_insured_premium[]" class="form-control name_insured_premium_4 mt-1" ></div><div class="col-md-3 col-form-label text-right">Premium:</div><div class="col-md-9"><input style="width:180px;" type="text" id="premium_'+add_pa_counter+'" name="premium[]" class="form-control premium mt-1" ></div></div></td></tr>';
        $("#first_table_tbody").append(tr_table);
    }

    sum_insured_dropdown();
    function sum_insured_dropdown() {
        var sum_Val = ["50,000","1,00,000", "2,00,000", "3,00,000", "4,00,000", "5,00,000", "6,00,000", "7,00,000", "8,00,000", "9,00,000", "10,00,000", "15,00,000", "20,00,000", "25,00,000", "30,00,000", "35,00,000", "40,00,000", "45,00,000", "50,00,000", "55,00,000", "60,00,000", "65,00,000", "70,00,000", "75,00,000", "80,00,000", "85,00,000", "90,00,000", "95,00,000", "1,00,00,000"];
        var i = 0;
        for (i; i <= 28; i++) {
            sum_insured_dropdown_val += '<option value="' + sum_Val[i] + '">' + sum_Val[i] + '</option>';
        }
        // alert(sum_insured_dropdown_val);
        $(".name_insured_sum_insured_1").empty();
        $(".name_insured_sum_insured_1").append('<option value="null">Select Sum Insured</option>'+sum_insured_dropdown_val);
        $(".name_insured_sum_insured_2").empty();
        $(".name_insured_sum_insured_2").append('<option value="null">Select Sum Insured</option>'+sum_insured_dropdown_val);  
        $(".name_insured_sum_insured_3").empty();
        $(".name_insured_sum_insured_3").append('<option value="null">Select Sum Insured</option>'+sum_insured_dropdown_val);
        $(".name_insured_sum_insured_4").empty();
        $(".name_insured_sum_insured_4").append('<option value="null">Select Sum Insured</option>'+sum_insured_dropdown_val);
        $(".name_insured_member_name").empty();
        $(".name_insured_member_name").append('<option value="null">Select Member Names</option>'+option_val_data);
        // $(".nominee_name").empty();
        // $(".nominee_name").append('<option value="null">Select Nominee Name</option>'+option_val_data);
    }

    var actual_data_PAccident = [];

    function Total_PAccident() {
        actual_data_PAccident = [];

        $("#first_table tr:has(.name_insured_member_name)").each(function(key, val) {

            var name_insured_member_name = $(".name_insured_member_name", this).val();
            var name_insured_member_name_txt = $(".name_insured_member_name option:selected", this).text();
            var name_insured_dob = $(".name_insured_dob", this).val();
            var name_insured_age = $(".name_insured_age", this).val();
            var name_insured_sum_insured_1 = $(".name_insured_sum_insured_1", this).val();
            var name_insured_sum_insured_2 = $(".name_insured_sum_insured_2", this).val();
            var name_insured_sum_insured_3 = $(".name_insured_sum_insured_3", this).val();
            var name_insured_sum_insured_4 = $(".name_insured_sum_insured_4", this).val();
            var sum_insured = $(".sum_insured", this).val();
            var name_insured_premium_1 = $(".name_insured_premium_1", this).val();
            var name_insured_premium_2 = $(".name_insured_premium_2", this).val();
            var name_insured_premium_3 = $(".name_insured_premium_3", this).val();
            var name_insured_premium_4 = $(".name_insured_premium_4", this).val();
            var premium = $(".premium", this).val();

            actual_data_PAccident.push([key, name_insured_member_name , name_insured_member_name_txt , name_insured_dob , name_insured_age , name_insured_sum_insured_1 , name_insured_sum_insured_2 , name_insured_sum_insured_3 , name_insured_sum_insured_4 , sum_insured , name_insured_premium_1 , name_insured_premium_2 , name_insured_premium_3 , name_insured_premium_4 , premium]);
            if (name_insured_member_name == '')
                actual_data_PAccident.splice(key, 1);
        });
        // console.log(actual_data_PAccident);
        // alert(actual_data_PAccident);
        return actual_data_PAccident;

        // var total_paccident = JSON.stringify(Total_PAccident());
        // alert(total_paccident);
        // return false;
    }
// Calculation Section Start

    function dateFormate(value) {
        var date = value.split("-");

        var day = (date[0]),
            month = (date[1]),
            year = (date[2]);

        if(!$.isNumeric(month)){
            month = getMonthFromString(month);
        }
        var new_date= new Date(year, month - 1, day).toLocaleDateString('en-CA');

        var date = new Date(new_date),
                get_y = date.getFullYear(),
                get_m = ("0" + (date.getMonth() + 1)).slice(-2);
                get_d=("0" + date.getDate()).slice(-2);

        var org_date = get_d+"-"+get_m+"-"+get_y;

         return org_date;
    }

    function getMonthFromString(mon){
        return new Date(Date.parse(mon +" 1, 2012")).getMonth()+1
    }

    function get_dob(add_pa_counter) {
        // alert(add_pa_counter);
        var rowCount = $('#first_table tbody tr').length;

        if(add_pa_counter == 0){
            var name_insured_relation =  $('#name_insured_relation_'+add_pa_counter+' option').filter(function () { return $(this).html() == "Self"; }).val();
            $('#name_insured_relation_'+add_pa_counter).val(name_insured_relation);
        }

        var name_insured_member_name = $("#name_insured_member_name_"+add_pa_counter).val();
        // alert(name_insured_member_name);
        var url = "<?php echo base_url(); ?>master/policy/get_membernameBased_details";

        if (name_insured_member_name != "") {
            $.ajax({
                url: url,
                data: {
                    member_name: name_insured_member_name
                },
                type: 'POST',
                dataType: 'json',
                async: false,
                cache: false,
                beforeSend: function() {},
                success: function(data) {
                    if (data["status"] == true) {
                        $('#name_insured_dob_'+add_pa_counter).val("");
                        var dob = data["userdata"].dob;
                        // alert(dob);
                        if(dob == "null"){
                            dob = "";
                            toaster(message_type = "Error", message_txt = "The DOB field is required.", message_icone = "error");
                        }else{
                            dob = dateFormate(dob);
                        }
                        // alert(dob);
                        $('#name_insured_dob_'+add_pa_counter).val(dob);
                        get_age(add_pa_counter);
                    } else {
                        $('#name_insured_dob_'+add_pa_counter).val("");
                    }
                },
                error: function(xhr, status) {
                    alert('Sorry, there was a problem!');
                },
                complete: function(xhr, status) {

                }
            });
        }
    }

    function get_age(add_pa_counter) {
        var name_insured_member_name = $("#name_insured_member_name_"+add_pa_counter).val();
        var name_insured_dob = $("#name_insured_dob_"+add_pa_counter).val();
        // alert(name_insured_dob);
        var url = "<?php echo base_url(); ?>master/policy/get_age_calculation_basedon_dob";

        if (name_insured_member_name != "") {
            $.ajax({
                url: url,
                data: {
                    member_id: name_insured_member_name,
                    dob: name_insured_dob
                },
                type: 'POST',
                dataType: 'json',
                async: false,
                cache: false,
                beforeSend: function() {},
                success: function(data) {
                    if (data["status"] == true) {
                        $('#name_insured_age_'+add_pa_counter).val("");
                        var age = data["age"];
                        $('#name_insured_age_'+add_pa_counter).val(age);
                        remove_policyType_basedonAge(add_pa_counter);
                    } else {
                        $('#name_insured_age_'+add_pa_counter).val("");
                    }
                    medi_ncd_amount_Cal();
                    medi_total_amount_Cal();
                },
                error: function(xhr, status) {
                    alert('Sorry, there was a problem!');
                },
                complete: function(xhr, status) {

                }
            });
        }
    }

    function getcolumnOnAge(age) {
        var column_value = "";
        if (age <= 25) {
            column_value = "91days_25years";
        } else if (age <= 30) {
            column_value = "26_30";
        } else if (age <= 35) {
            column_value = "31_35";
        } else if (age <= 40) {
            column_value = "36_40";
        } else if (age <= 45) {
            column_value = "41_45";
        } else if (age <= 50) {
            column_value = "46_50";
        } else if (age <= 55) {
            column_value = "51_55";
        } else if (age <= 60) {
            column_value = "56_60";
        }
        return column_value;
    }

    function get_premium(add_pa_counter){

        sum_insured_Cal(add_pa_counter);
    }

    function name_insured_sum_insured_INTVAl(Sum_insured){
        var new_sum_insured = "";
        if(Sum_insured == "50,000")
            new_sum_insured = 50000; 
        else if(Sum_insured == "1,00,000")
            new_sum_insured = 100000; 
        else if(Sum_insured == "2,00,000")
            new_sum_insured = 200000; 
        else if(Sum_insured == "3,00,000")
            new_sum_insured = 300000; 
        else if(Sum_insured == "4,00,000")
            new_sum_insured = 400000; 
        else if(Sum_insured == "5,00,000")
            new_sum_insured = 500000; 
        else if(Sum_insured == "6,00,000")
            new_sum_insured = 600000; 
        else if(Sum_insured == "7,00,000")
            new_sum_insured = 700000; 
        else if(Sum_insured == "8,00,000")
            new_sum_insured = 800000; 
        else if(Sum_insured == "9,00,000")
            new_sum_insured = 900000; 
        else if(Sum_insured == "10,00,000")
            new_sum_insured = 1000000; 
        else if(Sum_insured == "15,00,000")
            new_sum_insured = 1500000; 
        else if(Sum_insured == "20,00,000")
            new_sum_insured = 2000000; 
        else if(Sum_insured == "25,00,000")
            new_sum_insured = 2500000; 
        else if(Sum_insured == "30,00,000")
            new_sum_insured = 3000000; 
        else if(Sum_insured == "35,00,000")
            new_sum_insured = 3500000;
        else if(Sum_insured == "40,00,000")
            new_sum_insured = 4000000;
        else if(Sum_insured == "45,00,000")
            new_sum_insured = 4500000; 
        else if(Sum_insured == "50,00,000")
            new_sum_insured = 5000000; 
        else if(Sum_insured == "55,00,000")
            new_sum_insured = 5500000; 
        else if(Sum_insured == "60,00,000")
            new_sum_insured = 6000000; 
        else if(Sum_insured == "65,00,000")
            new_sum_insured = 6500000;  
        else if(Sum_insured == "70,00,000")
            new_sum_insured = 7000000; 
        else if(Sum_insured == "75,00,000")
            new_sum_insured = 7500000; 
        else if(Sum_insured == "80,00,000")
            new_sum_insured = 8000000; 
        else if(Sum_insured == "85,00,000")
            new_sum_insured = 8500000; 
        else if(Sum_insured == "90,00,000")
            new_sum_insured = 9000000; 
        else if(Sum_insured == "95,00,000")
            new_sum_insured = 9500000; 
        else if(Sum_insured == "1,00,00,000")
            new_sum_insured = 10000000; 

        return new_sum_insured;
    }

    function sum_insured_Cal(add_pa_counter) {

        var name_insured_sum_insured_1 = $("#name_insured_sum_insured_"+add_pa_counter+"_1").val();
        var name_insured_sum_insured_2 = $("#name_insured_sum_insured_"+add_pa_counter+"_2").val();
        var name_insured_sum_insured_3 = $("#name_insured_sum_insured_"+add_pa_counter+"_3").val();
        var name_insured_sum_insured_4 = $("#name_insured_sum_insured_"+add_pa_counter+"_4").val();

        name_insured_sum_insured_1 = name_insured_sum_insured_INTVAl(name_insured_sum_insured_1);
        name_insured_sum_insured_2 = name_insured_sum_insured_INTVAl(name_insured_sum_insured_2);
        name_insured_sum_insured_3 = name_insured_sum_insured_INTVAl(name_insured_sum_insured_3);
        name_insured_sum_insured_4 = name_insured_sum_insured_INTVAl(name_insured_sum_insured_4);

        name_insured_sum_insured_1 = parseInt(name_insured_sum_insured_1);
        name_insured_sum_insured_2 = parseInt(name_insured_sum_insured_2);
        name_insured_sum_insured_3 = parseInt(name_insured_sum_insured_3);
        name_insured_sum_insured_4 = parseInt(name_insured_sum_insured_4);
        var sum_insured = 0;
        if (isNaN(name_insured_sum_insured_1))
            name_insured_sum_insured_1 = 0;
        else
            name_insured_sum_insured_1 = name_insured_sum_insured_1;

        if (isNaN(name_insured_sum_insured_2))
            name_insured_sum_insured_2 = 0;
        else
            name_insured_sum_insured_2 = name_insured_sum_insured_2;

        if (isNaN(name_insured_sum_insured_3))
            name_insured_sum_insured_3 = 0;
        else
            name_insured_sum_insured_3 = name_insured_sum_insured_3;

        if (isNaN(name_insured_sum_insured_4))
            name_insured_sum_insured_4 = 0;
        else
            name_insured_sum_insured_4 = name_insured_sum_insured_4;

        sum_insured = name_insured_sum_insured_1 + name_insured_sum_insured_2 + name_insured_sum_insured_3 + name_insured_sum_insured_4;
        $("#sum_insured_"+add_pa_counter).val(sum_insured);
    }

    function premium_after_ncd_amount_Cal(add_pa_counter) {
        var ncd_amount = $("#ncd_amount_"+add_pa_counter).val();
        var premium_after_loading = $("#premium_after_loading_"+add_pa_counter).val();

        ncd_amount = parseInt(ncd_amount);
        premium_after_loading = parseInt(premium_after_loading);

        if (isNaN(ncd_amount))
            ncd_amount = 0;
        else
            ncd_amount = ncd_amount;

        if (isNaN(premium_after_loading))
            premium_after_loading = 0;
        else
            premium_after_loading = premium_after_loading;
        var premium_after_ncd_amount = (premium_after_loading - ncd_amount);
        $("#premium_after_ncd_amount_"+add_pa_counter).val(premium_after_ncd_amount);
        medi_ncd_amount_Cal(add_pa_counter);
        medi_total_amount_Cal(add_pa_counter);
    }

    // var ncd_amount_Total = 0;
    function medi_ncd_amount_Cal_bak(add_pa_counter) {
        var ncd_amount = $("#ncd_amount_"+add_pa_counter).val();

        ncd_amount = parseInt(ncd_amount);

        if (isNaN(ncd_amount))
            ncd_amount = 0;
        else
            ncd_amount = ncd_amount;

        $("#medi_total_ncd_amount").val(ncd_amount);
    }

    function medi_ncd_amount_Cal() {
        var inputs = $(".ncd_amount");
        var total = 0;
        for (var i = 0; i < inputs.length; i++) {
            var ncd_amount = $(inputs[i]).val();
            ncd_amount = parseInt(ncd_amount);
            if (isNaN(ncd_amount))
            ncd_amount = 0;
            else
            ncd_amount = ncd_amount;

            total = total + ncd_amount;
            $("#medi_total_ncd_amount").val(total);
        }
    }

    function medi_total_amount_Cal() {
        var inputs = $(".premium_after_ncd_amount");
        var total = 0;
        for (var i = 0; i < inputs.length; i++) {
            var premium_after_ncd_amount = $(inputs[i]).val();
            premium_after_ncd_amount = parseInt(premium_after_ncd_amount);
            if (isNaN(premium_after_ncd_amount))
            premium_after_ncd_amount = 0;
            else
            premium_after_ncd_amount = premium_after_ncd_amount;

            total = total + premium_after_ncd_amount;
            $("#medi_total_amount").val(total);
        }
        medi_family_disc_tot_Cal();
    }

    function medi_total_amount_Cal_bak(add_pa_counter) {
        var premium_after_ncd_amount = $("#premium_after_ncd_amount_"+add_pa_counter).val();

        premium_after_ncd_amount = parseInt(premium_after_ncd_amount);

        if (isNaN(premium_after_ncd_amount))
            premium_after_ncd_amount = 0;
        else
            premium_after_ncd_amount = premium_after_ncd_amount;
        $("#medi_total_amount").val(premium_after_ncd_amount);
        medi_family_disc_tot_Cal();
    }

    function medi_family_disc_tot_Cal() {
        var rowCount = $('#first_table tbody tr').length;
        // alert(rowCount);
        var vals=$("#medi_family_disc_rate").val();
        vals = parseInt(vals);

        if (isNaN(vals))
            vals = "#";
        else
            vals = vals;
        if (rowCount == 1) {
            $("#medi_family_disc_rate").val(0);
        } else if (rowCount == 2){
            if(vals==0 && vals!="#"){
                // alert(vals);
                $("#medi_family_disc_rate").val(5);
            }
        }
        var medi_family_disc_rate = $("#medi_family_disc_rate").val();
        var medi_total_amount = $("#medi_total_amount").val();

        medi_family_disc_rate = parseInt(medi_family_disc_rate);
        medi_total_amount = parseInt(medi_total_amount);

        if (isNaN(medi_family_disc_rate))
            medi_family_disc_rate = 0;
        else
            medi_family_disc_rate = medi_family_disc_rate;

        if (isNaN(medi_total_amount))
            medi_total_amount = 0;
        else
            medi_total_amount = medi_total_amount;

        if (rowCount == 1) {
            var medi_family_disc_tot = Math.round((medi_family_disc_rate * medi_total_amount) / 100);
            $("#medi_family_disc_tot").val(medi_family_disc_tot);
            // $("#medi_family_disc_tot").val(medi_total_amount);
        } else {
            var medi_family_disc_tot = Math.round((medi_family_disc_rate * medi_total_amount) / 100);
            $("#medi_family_disc_tot").val(medi_family_disc_tot);
        }
        medi_premium_after_fd_Cal();
    }

    function medi_premium_after_fd_Cal() {
        var medi_total_amount = $("#medi_total_amount").val();
        var medi_family_disc_tot = $("#medi_family_disc_tot").val();
        medi_total_amount = parseInt(medi_total_amount);
        medi_family_disc_tot = parseInt(medi_family_disc_tot);

        if (isNaN(medi_total_amount))
            medi_total_amount = 0;
        else
            medi_total_amount = medi_total_amount;

        if (isNaN(medi_family_disc_tot))
            medi_family_disc_tot = 0;
        else
            medi_family_disc_tot = medi_family_disc_tot;

        var medi_premium_after_fd = medi_total_amount-medi_family_disc_tot;

        $("#medi_premium_after_fd").val(medi_premium_after_fd);
        gst_apply();
    }

    function gst_apply() {
        var medi_premium_after_fd = $("#medi_premium_after_fd").val();
        var cgst_fire_per = $("#cgst_fire_per").val();
        var sgst_fire_per = $("#sgst_fire_per").val();

        cgst_fire_per = parseInt(cgst_fire_per);
        if (isNaN(cgst_fire_per))
            cgst_fire_per = 0;
        else
            cgst_fire_per = cgst_fire_per;

        sgst_fire_per = parseInt(sgst_fire_per);
        if (isNaN(sgst_fire_per))
            sgst_fire_per = 0;
        else
            sgst_fire_per = sgst_fire_per;

        medi_premium_after_fd = parseInt(medi_premium_after_fd);
        if (isNaN(medi_premium_after_fd))
            medi_premium_after_fd = 0;
        else
            medi_premium_after_fd = medi_premium_after_fd;

        if (medi_premium_after_fd == "") {
            $("#paccident_cgst_tot").val(0);
            $("#paccident_sgst_tot").val(0);
            $("#paccident_final_premium").val(0);
        }

        var paccident_cgst_tot = Math.round((medi_premium_after_fd * cgst_fire_per) / 100);
        var paccident_sgst_tot = Math.round((medi_premium_after_fd * sgst_fire_per) / 100);
        $("#paccident_cgst_tot").val(paccident_cgst_tot);
        $("#paccident_sgst_tot").val(paccident_sgst_tot);

        var paccident_final_premium = parseInt(medi_premium_after_fd) + parseInt(paccident_cgst_tot) + parseInt(paccident_sgst_tot);
        $("#paccident_final_premium").val(paccident_final_premium);

    }

    // Calculation Section End
</script>